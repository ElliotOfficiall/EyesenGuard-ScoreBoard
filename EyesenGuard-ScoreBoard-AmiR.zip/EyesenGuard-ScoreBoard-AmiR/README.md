# EyesenGuard-ScoreBoard
Inspired by elegance and heat – a fiery, modern UI
# Eysen Guard ScoreBoard

Give your server a bold identity with this stunning and powerful scoreboard!
Designed to showcase beauty, strength, and fire, the Eysen Guard Scoreboard brings immersive visuals and essential information right to your players’ screens.

:art: Inspired by elegance and heat – a fiery, modern UI
:zap: Optimized for performance – lightweight and smooth
:clock3: Displays server time, date, weather, and player/admin count
:police_car: Compatible with key roles: Police, Medic, Justice, Mechanic
:bulb: Works with ESX, QBCore, and custom frameworks

:sparkles: Video: https://youtu.be/u9omEh1SdgY
